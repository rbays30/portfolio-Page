#include <cs50.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int main(void)
{
    //obtain card number
    long card_number = get_long("What is your card number?: ");

    //Initial Check to Make Sure the User didn't type Zero which would break the code
    if (card_number == 0)
    {
        //Print Invalid if so...
        printf("INVALID\n");
    }

    //Presuming Things check out so far...
    else
    {
        //Obtain Length of Number
        int length = log10(labs(card_number)) + 1;

        //If Length of Number is outside of credit card range...
        if (length < 13 || length > 16)
        {
            //Print Invalid
            printf("INVALID\n");
        }

        //Assuming things are still good so far
        else
        {
            //Establish a Variable to operate on the credit card number without changing the original variable
            long card_loop = card_number;

            //Create an array of size length
            int digit [length];

            //Loop through the credit card number to assign specific digits to specific spaces 0-length-1
            for (int i = 0; i < length; i++)
            {
                //Identify the remainder when dividing by 10
                digit[length - 1 - i] = card_loop % 10;

                //subtract that digit from the current card number to make a zero at the end
                card_loop = card_loop - digit[length - 1 - i];

                //Divide by 10 to prepare for the next operation
                card_loop = card_loop / 10;
            }

            // Initialize Checksum Variables
            long checksum = 0;
            long addition = 0;

            //Calculate Checksum. Starts at last unit in the array, sets "addition" to whatever is to be added to the checksum
            for (int k = length - 2; k >= 0;)
            {
                addition = digit[k] * 2;

                //If the unit is above ten, split the addition into two seperate additions
                if (addition >= 10)
                {
                    addition = 1 + addition % 10;
                }

                //Add the addition to the check sum
                checksum = checksum + addition;

                //Subtract 2 to cycle through every other digit
                k = k - 2;
            }

            //Add the other numbers not multiplied by 2 to the checksum
            for (int m = length - 1; m >= 0;)
            {
                addition = digit[m];
                checksum = checksum + addition;
                m = m - 2;
            }

            //Check to make sure checksum checks out
            if (checksum % 10 == 0)
            {
                //If AMEX card...
                if (digit[0] == 3 && (digit[1] == 4 || digit[1] == 7))
                {
                    printf("AMEX\n");
                }

                //If Mastercard...
                else if (digit[0] == 5 && (digit[1] >= 1 && digit[1] <= 5))
                {
                    printf("MASTERCARD\n");
                }

                //If Visa ...
                else if (digit[0] == 4)
                {
                    printf("VISA\n");
                }

                //If not any of the above three
                else
                {
                    printf("INVALID\n");
                }
            }

            //If checksum test does not pass
            else
            {
                printf("INVALID\n");
            }
        }
    }
}

