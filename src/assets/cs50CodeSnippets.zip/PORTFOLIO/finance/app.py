import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd, user_cash

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # Grab information from SQL Table
    stocks_info = db.execute(
        "SELECT symbol, SUM(shares) as shares FROM transactions WHERE id = ? GROUP BY symbol", session["user_id"])
    stock_total = 0

    # Add stock data to dictionary
    for stock in stocks_info:
        stock_data = lookup(stock["symbol"])
        stock["price"] = stock_data["price"]
        stock["total"] = stock["price"] * stock["shares"]
        stock_total += stock["total"]

    # Obtain amount of user's current cash
    cash = user_cash()

    # Add values to reflect total
    grand_total = cash + stock_total

    return render_template("index.html", stocks_info=stocks_info, stock_total=stock_total, cash=cash, grand_total=grand_total)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "GET":
        return render_template("buy.html")
    else:

        # Validate Symbol is not blank
        if request.form.get("symbol"):
            symbol = request.form.get("symbol")
        else:
            return apology("Y no Symbol")

        # Validate Shares is not Blank
        if request.form.get("shares"):
            try:
                shares = int(request.form.get("shares"))
            except:
                return apology("Please enter a positive, whole number for shares", 400)
        else:
            return apology("Y no shares")

        if shares < 0:
            return apology("Shares need to be positive")

        # Lookup Symbol
        symbol_info = lookup(symbol)

        # Validate Symbol exists
        if symbol_info is None:
            return apology("No Symbol exists")

        # Lookup Cash on Hand
        cash = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
        cash = cash[0]["cash"]
        proposed_buy = float(symbol_info["price"]) * shares

        # Ensure user can cover the buy
        if cash < proposed_buy:
            return apology("No has money")
        else:

            # Put data in SQL Table
            cash = cash - proposed_buy
            db.execute("INSERT INTO transactions (id, symbol, shares, price, type) VALUES (?, ?, ?, ?, 'BUY')",
                       session["user_id"], symbol_info["symbol"], shares, symbol_info["price"])
            db.execute("UPDATE users SET cash = ? WHERE id = ?", cash, session["user_id"])

        return redirect("/")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""

    # Grab appropriate values from SQL table
    history = db.execute("SELECT symbol, shares, price, type, executed FROM transactions WHERE id = ?", session["user_id"])
    return render_template("history.html", history=history)


@app.route("/add_cash", methods=["GET", "POST"])
@login_required
def add_cash():
    """Allow user to add cash to account"""

    # Request Users cash
    cash = user_cash()

    if request.method == "GET":
        return render_template("add_cash.html", cash=cash)
    else:

        # Obtain and sanitize user's input
        if request.form.get("cash_value"):
            try:
                add_cash = float(request.form.get("cash_value"))
            except:
                return apology("Please enter a valid amount")

            # Update Cash
            db.execute("UPDATE users SET cash = ? WHERE id = ?", (cash + add_cash), session["user_id"])
            return redirect("/")

        else:
            return apology("Please enter a valid amount")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    if request.method == "GET":
        return render_template("quote.html")
    else:

        # Obtain stock information based on form
        symbol = request.form.get("symbol")
        symbol_info = lookup(symbol)

        # Ensure proper usage
        if symbol_info is not None:
            return render_template("quoted.html", symbol_info=symbol_info)
        else:
            return apology("Check Stock Symbol", 400)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "GET":

        return render_template("register.html")
    else:

        # If username is not entered
        if not request.form.get("username"):
            return apology("must provide username", 400)
        else:
            username = request.form.get("username")

        # If username already exists
        existing_usernames = db.execute("SELECT COUNT (username) FROM users WHERE username = ?", username)
        if (existing_usernames[0]["COUNT (username)"] > 0):
            return apology("Username Taken", 400)

        # If password is not entered
        if not request.form.get("password"):
            return apology("must provide password", 400)
        else:
            password = request.form.get("password")

        # If password confirmation is not entered
        if not request.form.get("confirmation"):
            return apology("must confirm password", 400)
        else:
            confirmation = request.form.get("confirmation")

        # If passwords match

        if password == confirmation:
            db.execute("INSERT INTO users (username,hash) VALUES (?, ?)", username,
                       generate_password_hash(password, method='pbkdf2:sha256', salt_length=8))
        else:
            return apology("Passwords don't match", 400)

    return render_template("login.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    # Grab information on the user's current owned stocks
    stocks_info = db.execute(
        "SELECT symbol, SUM(shares) as shares FROM transactions WHERE id = ? GROUP BY symbol", session["user_id"])
    available_stocks = []
    for stock in stocks_info:
        available_stocks.append(stock["symbol"])

    # Render basic template if navigating to the page
    if request.method == "GET":
        return render_template("sell.html", available_stocks=available_stocks)
    else:

        # Grab stock information based on form
        symbol = request.form.get("symbol")

        # Ensure stock is in the user's available stocks
        if symbol not in available_stocks:
            return apology("Stock Not Found")

        # Grab input from user of number of shares to sell
        shares = request.form.get("shares")
        try:
            shares = int(shares)
        except:
            return apology("Please Input a Positive Integer for Shares")

        # Check to make sure user owns enough stock
        owned_stock = 0
        for stock in stocks_info:
            if stock["symbol"] == symbol:
                owned_stock = stock["shares"]
        if owned_stock < shares:
            return apology("Not Enough Stock")

        # Calculate Proposed Sell
        symbol_info = lookup(symbol)
        proposed_sell = float(symbol_info["price"]) * shares

        # Update cash for the user
        cash = user_cash()
        cash += proposed_sell

        # Submit to db
        db.execute("INSERT INTO transactions (id, symbol, shares, price, type) VALUES (?, ?, ?, ?, 'SELL')",
                   session["user_id"], symbol_info["symbol"], (-1 * shares), symbol_info["price"])
        db.execute("UPDATE users SET cash = ? WHERE id = ?", cash, session["user_id"])

        return redirect("/")