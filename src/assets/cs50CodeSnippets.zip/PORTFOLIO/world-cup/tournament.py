# Simulate a sports tournament

import csv
import sys
import random

# Number of simluations to run
N = 1000


def main():

    # Ensure correct usage
    if len(sys.argv) != 2:
        sys.exit("Usage: python tournament.py FILENAME")

    # Initialize teams list
    teams = []

    # Open file and Read file
    with open(sys.argv[1]) as f:
        reader = csv.DictReader(f)
        for row in reader:

            # Save temporary values for indexing
            team = (row['team'])
            rating = int(row['rating'])

            # Create dictionary of values along with team names
            Dict = {'team': team, 'rating': rating}
            teams.append(Dict)

    # Initialize winner count dictionary
    counts = {}

    # Simulate N tournaments and keep track of win counts
    for i in range(N):

        # Set winners name equal to the output of simulate_tournaments
        winner = simulate_tournament(teams)

        # If winner has already won
        if winner in counts:
            counts[winner] += 1

        # If new winner
        else:
            counts[winner] = 1

    # Print each team's chances of winning, according to simulation
    for team in sorted(counts, key=lambda team: counts[team], reverse=True):
        print(f"{team}: {counts[team] * 100 / N:.1f}% chance of winning")


def simulate_game(team1, team2):
    """Simulate a game. Return True if team1 wins, False otherwise."""
    rating1 = team1["rating"]
    rating2 = team2["rating"]
    probability = 1 / (1 + 10 ** ((rating2 - rating1) / 600))
    return random.random() < probability


def simulate_round(teams):
    """Simulate a round. Return a list of winning teams."""
    winners = []

    # Simulate games for all pairs of teams
    for i in range(0, len(teams), 2):
        if simulate_game(teams[i], teams[i + 1]):
            winners.append(teams[i])
        else:
            winners.append(teams[i + 1])

    return winners


def simulate_tournament(teams):
    """Simulate a tournament. Return name of winning team."""

    # While a winner has not yet been determined
    while len(teams) > 1:

        # Set the teams array equal to the output of simulate round, which should be a list of winners
        teams = simulate_round(teams)

    # Grab dictionary value of champion
    winner_dic = teams[0]

    # return the name of that team
    return winner_dic["team"]


if __name__ == "__main__":
    main()
