#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wav.h"

int check_format(WAVHEADER header);
int get_block_size(WAVHEADER header);



int main(int argc, char *argv[])
{
    // Ensure proper usage
    if (argc != 3)
    {
        printf("Usage: ./reverse input.wav output.wav\n");
        return 1;
    }

    // Open input file for reading
    FILE *input = fopen(argv[1], "r");

    //Check if error
    if (input == NULL)
    {
        printf("Error opening file.\n");
        return 1;
    }

    // Initialize header
    WAVHEADER header;
    fread(header.chunkID, sizeof(BYTE), 4, input);
    fread(&header.chunkSize, sizeof(DWORD), 1, input);
    fread(header.format, sizeof(BYTE), 4, input);
    fread(header.subchunk1ID, sizeof(BYTE), 4, input);
    fread(&header.subchunk1Size, sizeof(DWORD), 1, input);
    fread(&header.audioFormat, sizeof(WORD), 1, input);
    fread(&header.numChannels, sizeof(WORD), 1, input);
    fread(&header.sampleRate, sizeof(DWORD), 1, input);
    fread(&header.byteRate, sizeof(DWORD), 1, input);
    fread(&header.blockAlign, sizeof(WORD), 1, input);
    fread(&header.bitsPerSample, sizeof(WORD), 1, input);
    fread(header.subchunk2ID, sizeof(BYTE), 4, input);
    fread(&header.subchunk2Size, sizeof(DWORD), 1, input);

    // Use check_format to ensure WAV format
    if (!check_format(header))
    {
        printf("File is not in WAV format.\n");
        return 1;
    }

    // Open output file for writing
    // TODO #5

    FILE *output = fopen(argv[2], "w");

    //Check if error
    if (output == NULL)
    {
        printf("Error opening file.\n");
        return 1;
    }

    // Write header to file
    // TODO #6

    fwrite(header.chunkID, sizeof(BYTE), 4, output);
    fwrite(&header.chunkSize, sizeof(DWORD), 1, output);
    fwrite(header.format, sizeof(BYTE), 4, output);
    fwrite(header.subchunk1ID, sizeof(BYTE), 4, output);
    fwrite(&header.subchunk1Size, sizeof(DWORD), 1, output);
    fwrite(&header.audioFormat, sizeof(WORD), 1, output);
    fwrite(&header.numChannels, sizeof(WORD), 1, output);
    fwrite(&header.sampleRate, sizeof(DWORD), 1, output);
    fwrite(&header.byteRate, sizeof(DWORD), 1, output);
    fwrite(&header.blockAlign, sizeof(WORD), 1, output);
    fwrite(&header.bitsPerSample, sizeof(WORD), 1, output);
    fwrite(header.subchunk2ID, sizeof(BYTE), 4, output);
    fwrite(&header.subchunk2Size, sizeof(DWORD), 1, output);

    // Use get_block_size to calculate size of block
    // TODO #7

    int block_size = get_block_size(header);


    // Write reversed audio to file
    // TODO #8

    //Initialize buffer
    BYTE buffer[block_size];

    //Place index at end of input file
    fseek(input, -4, SEEK_END);

    long index = ftell(input);
    long offset = -2 * block_size;

    //Write value to buffer
    while (index >= 44)
    {
        //Read the next chunk, writing it to buffer
        fread(buffer, sizeof(BYTE), block_size, input);

        //Set position back 8
        fseek(input, offset, SEEK_CUR);

        //Write buffer to file

        fwrite(buffer, sizeof(BYTE), block_size, output);

        //Update index to track when program is over

        index -= block_size;

    }

    //Close file
    fclose(input);
    fclose(output);




}


int check_format(WAVHEADER header)
{
    // TODO #4
    //Translate header format to a pointer

    BYTE *format_string = &header.format[0];

    //Check to make sure the format is the same character by character
    if (format_string[0] != 'W' || format_string[1] != 'A' || format_string[2] != 'V' || format_string[3] != 'E')
    {
        printf("Input is not a WAV file.\n");
        return 0;
    }
    return 1;
}

int get_block_size(WAVHEADER header)
{
    // TODO #7

    int block_size = (header.numChannels * header.bitsPerSample) / 8;
    return block_size;
}


